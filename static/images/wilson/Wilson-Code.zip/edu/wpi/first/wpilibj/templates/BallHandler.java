package edu.wpi.first.wpilibj.templates;

import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Jaguar;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.Timer;

public class BallHandler {
    Relay intake = new Relay(1);
    DigitalInput ballDetector = new DigitalInput(1);
    
    Jaguar kicker = new Jaguar(5);
    Timer kickerTimer = new Timer();
    boolean kickerTimerRunning = false;
    DigitalInput kickerDetector = new DigitalInput(3);
    
    
    public BallHandler() {
        
    }
    
    public void gather() {
        if (ballDetector.get())
            intake.set(Relay.Value.kForward);
        else
            intake.set(Relay.Value.kOff);
        
        if (!kickerDetector.get())
            kicker.set(-0.25);
        kickerTimer.stop();
        kickerTimerRunning = false;
    }
    
    public void shoot() {
        if (!kickerTimerRunning)
            kickerTimer.start();
        kickerTimerRunning = true;
        
        if (kickerTimer.get()>0.3) {
            kicker.set(0);
            intake.set(Relay.Value.kOff);
        } else {
            kicker.set(1);
            intake.set(Relay.Value.kReverse);
        }
        
    }
    
    public void reset() {
        intake.set(Relay.Value.kOff);
        
        if (!kickerDetector.get())
            kicker.set(-0.25);
        
        kickerTimer.stop();
        kickerTimerRunning = false;
    }
}
