/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package edu.wpi.first.wpilibj.templates;


import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Wilson extends IterativeRobot {
    public KiwiDrive drive = new KiwiDrive();
    public AIRFLOController controller = new AIRFLOController(1);
    public BallHandler ballHandler = new BallHandler();
    
    public void robotInit() {
        drive.putRequiredDashboardValues();
    }
    
    public void autonomousInit() {
        drive.putRequiredDashboardValues();
    }

    public void teleopInit() {
        drive.putRequiredDashboardValues();
    }
    
    
    public void teleopPeriodic() {
        if (controller.getButtonTripped(10))
            drive.toggleFieldOriented();
        if (controller.getButtonTripped(9))
            drive.toggleRegulation();
        
        if (controller.getHeadingPadPressed())
            drive.setHeading(controller.getHeadingPadDirection());
        
        drive.driveXYW(controller.getLX(), controller.getLY(), controller.getRX(), controller.getThrottle());
        
        
        
        if (controller.getRawButton(6))
            ballHandler.shoot();
        else if (controller.getRawButton(5))
            ballHandler.gather();
        else
            ballHandler.reset();
        
        SmartDashboard.putBoolean("Gyro Connected?", drive.imu != null && drive.imu.isConnected() );
        SmartDashboard.putNumber("Robot Heading", drive.getCurrentHeading());
        SmartDashboard.putBoolean("Regulating Heading?", drive.regulated);
        SmartDashboard.putBoolean("Field Oriented Drive?", drive.fieldOriented);
    }
    
    /**
     * This function is called periodically during test mode
     */
    public void testPeriodic() {
    
    }
    
}
