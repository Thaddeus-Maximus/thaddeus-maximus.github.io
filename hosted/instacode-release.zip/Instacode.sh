#!/bin/bash

cd ~/Instacode
chmod +x nbc
python Instacode.pyw
